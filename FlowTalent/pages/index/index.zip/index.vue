<template>
	<view>
		<!-- 测试发送get请求 -->
		<!-- <button @click="getCarousel()">发送get请求</button> -->
		<!-- 测试结束 -->
		<!-- 首页轮播图开始 -->
		<view>
			<swiper class="carousel" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" indicator-color="#fff" indicator-active-color="#0aa1ed">
				<swiper-item>
					<image class="sw-img" src="../../static/images/index-carousel/01—carousel.png"></image>
				</swiper-item>
				<swiper-item>
					<image class="sw-img" src="../../static/images/index-carousel/02—carousel.png"></image>
				</swiper-item>
				<swiper-item>
					<image class="sw-img" src="../../static/images/index-carousel/03—carousel.png"></image>
				</swiper-item>
				<swiper-item>
					<image class="sw-img" src="../../static/images/index-carousel/04—carousel.jpg"></image>
				</swiper-item>
				<swiper-item>
					<image class="sw-img" src="../../static/images/index-carousel/05—carousel.png"></image>
				</swiper-item>
			</swiper>
		</view>
		<!-- 首页轮播图结束 -->
		<!-- 首页流量宝开始 -->
		<!-- <image :src="icons"></image> -->
		<!-- 首页流量宝结束 -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		onLoad() {
			this.getCarousel();
		},
		methods: {
		getCarousel(){
			uni.request({
				url:"/api/lunbo",
				method:"GET",
				success:function(res) {
					console.log(res);
				}
			})
		}
		}
	}
</script>

<style>
	@import url("./index.css");
</style>
